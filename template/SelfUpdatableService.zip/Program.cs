﻿using System;
using System.IO;
using System.Reflection;
using Squirrel;
using Topshelf.Squirrel.Windows;
using Topshelf.Squirrel.Windows.Interfaces;

namespace $safeprojectname$
{
	class Program
	{
		static void Main(string[] args)
		{
			//This path should be replaced by one where to look for updates
			var serviceUpdatePath = "C:\\Updates";
			var appName = Assembly.GetExecutingAssembly().GetName().Name;
			ISelfUpdatableService service = new ServiceImplementation();
			IUpdater selfupdater = null;
			if (!Environment.UserInteractive)
			{
				string path = Path.Combine(serviceUpdatePath, appName);
				IUpdateManager updateManager = new UpdateManager(path);
				selfupdater = new RepeatedTimeUpdater(updateManager)
					.SetCheckUpdatePeriod(TimeSpan.FromSeconds(10));
			}

			var serviceName = appName;
			var host = new SquirreledHost(service, serviceName, serviceName, selfupdater, withOverlapping: true, promtCredsWhileInstall: false);
			host.ConfigureAndRun(hostConfigurator =>
			{
				hostConfigurator.SetDescription("Self-Updatable Service");
			});
		}
	}
}
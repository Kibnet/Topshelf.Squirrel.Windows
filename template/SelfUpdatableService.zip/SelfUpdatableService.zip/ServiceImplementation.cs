﻿using Topshelf.Squirrel.Windows.Interfaces;

namespace $safeprojectname$
{
	public class ServiceImplementation : ISelfUpdatableService
	{
		public void Start()
		{

		}

		public void Stop()
		{

		}
	}
}